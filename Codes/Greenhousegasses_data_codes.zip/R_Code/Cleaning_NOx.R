library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data

NOx_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/NOx_Emissions.csv")
View(NOx_Emissions)

nox_emission_df <- data.frame(NOx_Emissions)


#Dropping unwanted columns
nox_emission_drop <- subset(nox_emission_df,select=-c(1,32,33))

View(nox_emission_drop)

#Dropping NA values from Coutry column
nox_emission_drop[is.na(nox_emission_drop)] = "Country"


write.csv(nox_emission_drop,"~/Downloads/archive (2)/Air and Climate/NOx_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file
nox_data=read.csv("~/Downloads/archive (2)/Air and Climate/NOx_Emissions_Updated.csv", skip=1, header=TRUE)

View(nox_data)

#Unpivotting the data to have year data at row level

nox_emissions_unpivot<-gather(nox_data, year, value, `X1990`:`X2018`)

View(nox_emissions_unpivot)

colnames(nox_emissions_unpivot) <- c('Country','% change since 1990','NOx emissions 
per capita','Year','Total NOx Emissions')




#Cleaning column headings
nox_emissions_unpivot$Year<-gsub("X","",as.character(nox_emissions_unpivot$Year))



#Changing datatypes
nox_emissions_unpivot$`Total NOx Emissions` <- as.numeric(gsub(",","",nox_emissions_unpivot$`Total NOx Emissions`))
nox_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",nox_emissions_unpivot$`% change since 1990`))

nox_emissions_unpivot[,c(5)] <- sapply(nox_emissions_unpivot[, c(5)], as.numeric)
View(nox_emissions_unpivot)

Clean_Data<-nox_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)

#Changing Column headings
colnames(Clean_Data) <- c('Country','%Nox_change_since_1990','NOx_emissions_per_capita',
                          'Year','Total_NOx_Emissions')




View(Clean_Data)

#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_NOx.csv", row.names = FALSE)

