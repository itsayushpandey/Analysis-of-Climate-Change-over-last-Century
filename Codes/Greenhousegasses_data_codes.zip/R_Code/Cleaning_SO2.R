library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data

SO2_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/SO2_Emissions.csv")
View(SO2_Emissions)

so2_emission_df <- data.frame(SO2_Emissions)


#Dropping unwanted columns
so2_emission_drop <- subset(so2_emission_df,select=-c(1,32,33))

View(so2_emission_drop)

#Dropping NA values from Coutry column
so2_emission_drop[is.na(so2_emission_drop)] = "Country"

write.csv(so2_emission_drop,"~/Downloads/archive (2)/Air and Climate/SO2_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file
so2_data=read.csv("~/Downloads/archive (2)/Air and Climate/SO2_Emissions_Updated.csv", skip=1, header=TRUE)

View(so2_data)

#Unpivotting the data to have year data at row level
so2_emissions_unpivot<-gather(so2_data, year, value, `X1990`:`X2018`)

View(so2_emissions_unpivot)

colnames(so2_emissions_unpivot) <- c('Country','% change since 1990','SO2 emissions 
per capita','Year','Total SO2 Emissions')



#Cleaning column headings

so2_emissions_unpivot$Year<-gsub("X","",as.character(so2_emissions_unpivot$Year))
#str(Clean_Data)


#Changing datatypes
so2_emissions_unpivot$`Total SO2 Emissions` <- as.numeric(gsub(",","",so2_emissions_unpivot$`Total SO2 Emissions`))
so2_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",so2_emissions_unpivot$`% change since 1990`))

so2_emissions_unpivot[,c(5)] <- sapply(so2_emissions_unpivot[, c(5)], as.numeric)
View(so2_emissions_unpivot)

Clean_Data<-so2_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)

#Changing Column headings
colnames(Clean_Data) <- c('Country','%SO2_change_since_1990','SO2_emissions_per_capita',
                          'Year','Total_SO2_Emissions')




View(Clean_Data)
#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_SO2.csv", row.names = FALSE)

