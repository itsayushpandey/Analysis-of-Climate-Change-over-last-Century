library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data

CO2_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/CO2_Emissions.csv")
View(CO2_Emissions)

co2_emission_df <- data.frame(CO2_Emissions)


#Dropping unwanted columns
co2_emission_drop <- subset(co2_emission_df,select=-c(1,32,33))

View(co2_emission_drop)

#Dropping NA values from Coutry column
co2_emission_drop[is.na(co2_emission_drop)] = "Country"

write.csv(co2_emission_drop,"~/Downloads/archive (2)/Air and Climate/CO2_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file
co2_data=read.csv("~/Downloads/archive (2)/Air and Climate/CO2_Emissions_Updated.csv", skip=1, header=TRUE)

View(co2_data)


#Unpivotting the data to have year data at row level
co2_emissions_unpivot<-gather(co2_data, year, value, `X1990`:`X2018`)

View(co2_emissions_unpivot)


#Cleaning column headings

colnames(co2_emissions_unpivot) <- c('Country','% change since 1990','CO2 emissions 
per capita','Year','Total CO2 Emissions')

#Changing datatypes
co2_emissions_unpivot$Year<-gsub("X","",as.character(co2_emissions_unpivot$Year))

co2_emissions_unpivot$`Total CO2 Emissions` <- as.numeric(gsub(",","",co2_emissions_unpivot$`Total CO2 Emissions`))
co2_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",co2_emissions_unpivot$`% change since 1990`))

co2_emissions_unpivot[,c(5)] <- sapply(co2_emissions_unpivot[, c(5)], as.numeric)
View(co2_emissions_unpivot)

Clean_Data<-co2_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)

#Changing Column headings
colnames(Clean_Data) <- c('Country','%CO2_change_since_1990','CO2_emissions_per_capita',
                          'Year','Total_CO2_Emissions')




View(Clean_Data)
#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_CO2.csv", row.names = FALSE)

