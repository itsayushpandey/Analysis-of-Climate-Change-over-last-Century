library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data
CH4_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/CH4_Emissions.csv")


ch4_emission_df <- data.frame(CH4_Emissions)



#Dropping unwanted columns
ch4_emission_drop <- subset(ch4_emission_df,select=-c(1,32,33))


#Dropping NA values from Coutry column

ch4_emission_drop[is.na(ch4_emission_drop)] = "Country"

write.csv(ch4_emission_drop,"~/Downloads/archive (2)/Air and Climate/CH4_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file

ch4_data=read.csv("~/Downloads/archive (2)/Air and Climate/CH4_Emissions_Updated.csv", skip=1, header=TRUE)

str(ch4_data)

#Unpivotting the data to have year data at row level

ch4_emissions_unpivot<-gather(ch4_data, year, value, `X1990`:`X2018`)


#Cleaning column headings

colnames(ch4_emissions_unpivot) <- c('Country','% change since 1990','CH4 emissions 
per capita','Year','Total CH4 Emissions')



ch4_emissions_unpivot$Year<-gsub("X","",as.character(ch4_emissions_unpivot$Year))
str(Clean_Data)


#Changing datatypes
ch4_emissions_unpivot$`Total CH4 Emissions` <- as.numeric(gsub(",","",ch4_emissions_unpivot$`Total CH4 Emissions`))
ch4_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",ch4_emissions_unpivot$`% change since 1990`))

ch4_emissions_unpivot[,c(5)] <- sapply(ch4_emissions_unpivot[, c(5)], as.numeric)
View(ch4_emissions_unpivot)

Clean_Data<-ch4_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)

#Changing Column headings
colnames(Clean_Data) <- c('Country','%CH4_change_since_1990','CH4_emissions_per_capita',
                          'Year','Total_CH4_Emissions')




View(Clean_Data)
#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_CH4.csv", row.names = FALSE)

