library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data
GHG_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/GHG_Emissions.csv")
View(GHG_Emissions)

ghg_emission_df <- data.frame(GHG_Emissions)


#Dropping unwanted columns
ghg_emission_drop <- subset(ghg_emission_df,select=-c(1,32,33))

View(ghg_emission_drop)

#Dropping NA values from Coutry column

ghg_emission_drop[is.na(ghg_emission_drop)] = "Country"

write.csv(ghg_emission_drop,"~/Downloads/archive (2)/Air and Climate/GHG_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file

ghg_data=read.csv("~/Downloads/archive (2)/Air and Climate/GHG_Emissions_Updated.csv", skip=1, header=TRUE)

View(ghg_data)

#Unpivotting the data to have year data at row level

ghg_emissions_unpivot<-gather(ghg_data, year, value, `X1990`:`X2018`)

View(ghg_emissions_unpivot)

#Cleaning column headings
colnames(ghg_emissions_unpivot) <- c('Country','% change since 1990','GHG emissions 
per capita','Year','Total GHG Emissions')





ghg_emissions_unpivot$Year<-gsub("X","",as.character(ghg_emissions_unpivot$Year))
#str(Clean_Data)


#Changing datatypes
ghg_emissions_unpivot$`Total GHG Emissions` <- as.numeric(gsub(",","",ghg_emissions_unpivot$`Total GHG Emissions`))
ghg_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",ghg_emissions_unpivot$`% change since 1990`))

ghg_emissions_unpivot[,c(5)] <- sapply(ghg_emissions_unpivot[, c(5)], as.numeric)
View(ghg_emissions_unpivot)

Clean_Data<-ghg_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)

#Changing Column headings
colnames(Clean_Data) <- c('Country','%GHG_change_since_1990','GHG_emissions_per_capita',
                          'Year','Total_GHG_Emissions')




View(Clean_Data)

#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_GHG.csv", row.names = FALSE)

