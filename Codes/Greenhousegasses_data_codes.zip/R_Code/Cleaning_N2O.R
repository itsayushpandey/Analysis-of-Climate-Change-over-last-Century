library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading the data

N2O_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/N2O_Emissions.csv")
View(N2O_Emissions)

n2o_emission_df <- data.frame(N2O_Emissions)


#Dropping unwanted columns
n2o_emission_drop <- subset(n2o_emission_df,select=-c(1,32,33))

View(n2o_emission_drop)

#Dropping NA values from Coutry column

n2o_emission_drop[is.na(ghg_emission_drop)] = "Country"

write.csv(n2o_emission_drop,"~/Downloads/archive (2)/Air and Climate/N2O_Emissions_Updated.csv", row.names = FALSE)

#Formatting headings in this new csv file
n2o_data=read.csv("~/Downloads/archive (2)/Air and Climate/N2O_Emissions_Updated.csv", skip=1, header=TRUE)

View(n2o_data)

#Unpivotting the data to have year data at row level

n2o_emissions_unpivot<-gather(n2o_data, year, value, `X1990`:`X2018`)

View(n2o_emissions_unpivot)

#Cleaning column headings

colnames(n2o_emissions_unpivot) <- c('Country','% change since 1990','N2O emissions 
per capita','Year','Total N2O Emissions')





n2o_emissions_unpivot$Year<-gsub("X","",as.character(n2o_emissions_unpivot$Year))
#str(Clean_Data)


#Changing datatypes
n2o_emissions_unpivot$`Total N2O Emissions` <- as.numeric(gsub(",","",n2o_emissions_unpivot$`Total N2O Emissions`))
n2o_emissions_unpivot$`% change since 1990`<- as.numeric(gsub(",","",n2o_emissions_unpivot$`% change since 1990`))

n2o_emissions_unpivot[,c(5)] <- sapply(n2o_emissions_unpivot[, c(5)], as.numeric)
View(n2o_emissions_unpivot)

Clean_Data<-n2o_emissions_unpivot
Clean_Data$`Year`<- as.numeric(Clean_Data$`Year`)

View(Clean_Data)
#Changing Column headings
colnames(Clean_Data) <- c('Country','%NO2_change_since_1990','N2O_emissions_per_capita',
                          'Year','Total_N2O_Emissions')




View(Clean_Data)
#The final csv file
write.csv(Clean_Data,"~/Downloads/archive (2)/Air and Climate/Clean_Data_N2O.csv", row.names = FALSE)

