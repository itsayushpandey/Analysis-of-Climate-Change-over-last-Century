library(readr)
library(dplyr)
library(tidyr)
library(reshape)

library(ggplot2)

#Loading all the files to be merged 
SO2_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_SO2.csv")
CO2_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_CO2.csv")
GHG_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_GHG.csv")
N2O_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_N2O.csv")
NOx_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_NOx.csv")
CH4_Emissions <- read_csv("~/Downloads/archive (2)/Air and Climate/Clean_Data_CH4.csv")

#coverting to dataframe
so2_emission_df <- data.frame(SO2_Emissions)
co2_emission_df <- data.frame(CO2_Emissions)
ghg_emission_df <- data.frame(GHG_Emissions)
n2o_emission_df <- data.frame(N2O_Emissions)
nox_emission_df <- data.frame(NOx_Emissions)
ch4_emission_df <- data.frame(CH4_Emissions)


#Merging all the files
join1 <- full_join( so2_emission_df, co2_emission_df,by=c("Country","Year"))
join2 <- full_join( join1, ghg_emission_df,by=c("Country","Year"))
join3 <- full_join( join2, n2o_emission_df,by=c("Country","Year"))
join4 <- full_join( join3, nox_emission_df,by=c("Country","Year"))
join5 <- full_join( join4, ch4_emission_df,by=c("Country","Year"))

final <-select(join5,1,4,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)

View(final)


#Final Dataset
write.csv(final,"~/Downloads/archive (2)/Air and Climate/Final_Dataset.csv", row.names =FALSE)
